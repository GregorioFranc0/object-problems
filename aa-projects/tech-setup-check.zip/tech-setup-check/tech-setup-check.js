// This is a single-line comment in JavaScript. It starts with //.

/*
This is a
multi-line comment
in JavaScript.
*/

console.log("Hello World!")
// console.log is used to print messages or values to the console.
